#!/bin/bash

set -o errexit
set -o nounset

# resolve symlinks and canonicalize the path (make it absolute)
pushd . > /dev/null
this=$0
cd $(dirname ${this})
this=$(basename ${this})
while [ -L "${this}" ]
do
    this=$(readlink ${this})
    cd $(dirname ${this})
    this=$(basename ${this})
done
this="$(pwd -P)/${this}"
popd > /dev/null

HOMEDIR=$(dirname ${this})
LIB_EXTENSION="$(dirname ${HOMEDIR})/lib/extension"
HTTP_PORT=9000
MANAGEMENT_HOME=${VEMTEST_HOME:-"$HOME/.voltdb"}
BACKGROUND=false
HTTP_ADDRESS=0.0.0.0
ENABLE_ELASTIC=elastic
VEM_DEBUG_OPTS=${VEM_DEBUG_OPTS:=""}

# Use MANAGEMENT_HOME for logging if HOMEDIR isn't writeable.
if (touch "$HOMEDIR/test_write" 2> /dev/null); then
    rm -f "$HOMEDIR/test_write"
    LOGDIR="$HOMEDIR"
else
    echo "Logging to $MANAGEMENT_HOME/..."
    LOGDIR="$MANAGEMENT_HOME"
fi

# Adjust for Linux package installation layout as needed.
if [ -f "$HOMEDIR/enterprise_manager.jar" ]; then
    VOLTLIBDIR="$HOMEDIR"
    LICENSE="$HOMEDIR/../voltdb/license.xml"
else
    VOLTLIBDIR="$HOMEDIR/../../../lib/voltdb"
    LICENSE="$VOLTLIBDIR/license.xml"
fi

usage() {
    echo "Usage: `basename $0` [-b] [-p #httpPort] [-m path] [-l licensePath] [-x extensionLibPath]" \
         "[-a httpListenAddress] [ -o { elastic | noelastic }] "
    echo
    echo "The enterprise_manager.jar and the user credential file must be in the same" \
         "directory as this script"
    exit 0
}

checkJar() {
    if [ ! -f $VOLTLIBDIR/enterprise_manager.jar ]
    then
        echo "enterprise_manager.jar does not exist"
        usage
        exit 1
    fi
}

checkUsers() {
    if [ ! -f $HOMEDIR/users.xml ]
    then
        echo "users.xml credential file does not exist"
        usage
        exit 1
    fi
}

checkLicenseFile() {
    if [ ! -f "$LICENSE" ]
    then
        LICENSE="$MANAGEMENT_HOME/license.xml"
    fi
}

checkManagementHome() {
    if [ ! -d "$MANAGEMENT_HOME" ]
    then
        mkdir -p "$MANAGEMENT_HOME"
    else
        rm -rf "$MANAGEMENT_HOME/winstoneEmbeddedWAR"
    fi
}

runjava() {
    java -Xms256m -server $VEM_DEBUG_OPTS \
        -Dvolt.management.home=$2 \
        -Dlicense=$3 \
        -Dvolt.lib.extension=$4 \
        -Delastic=$6 \
        -Dlog4j.configuration=file:$HOMEDIR/enterprise_manager_log4j.properties \
        -Dvolt.server.log4j=$HOMEDIR/server_log4j.properties \
        -jar $VOLTLIBDIR/enterprise_manager.jar \
        --realmClassName=winstone.realm.FileRealm \
        --fileRealm.configFile=$HOMEDIR/users.xml \
        --httpListenAddress=$5 \
        --httpPort=$1 --ajp13Port=-1 \
        --logfile=$LOGDIR/vemcontainer.log
}

waitOnLaunch() {
    while ! grep -q "VoltDB Enterprise Manager has finished initialization" $MANAGEMENT_HOME/stdout.txt
    do
        sleep 1
    done
}

runjavabackground() {
    nohup java -Xms256m -server $VEM_DEBUG_OPTS \
        -Dvolt.management.home=$2 \
        -Dlicense=$3 \
        -Dvolt.lib.extension=$4 \
        -Delastic=$6 \
        -Dlog4j.configuration=file:$HOMEDIR/enterprise_manager_log4j.properties \
        -Dvolt.server.log4j=$HOMEDIR/server_log4j.properties \
        -jar $VOLTLIBDIR/enterprise_manager.jar \
        --realmClassName=winstone.realm.FileRealm \
        --fileRealm.configFile=$HOMEDIR/users.xml \
        --httpListenAddress=$5 \
        --httpPort=$1 --ajp13Port=-1 \
        --logfile=$LOGDIR/vemcontainer.log &> $MANAGEMENT_HOME/stdout.txt &
}

launch() {
    if ( set -o noclobber; echo "$$" > "$LOCKFILE") 2> /dev/null;
    then
       trap 'rm -f "$LOCKFILE"; exit $?' INT TERM EXIT
       if $BACKGROUND
       then
           runjavabackground $HTTP_PORT "$MANAGEMENT_HOME" "$LICENSE" "$LIB_EXTENSION" "$HTTP_ADDRESS" $ENABLE_ELASTIC
           waitOnLaunch
           echo "VoltDB enterprise manager started in background..."
       else
           runjava $HTTP_PORT "$MANAGEMENT_HOME" "$LICENSE" "$LIB_EXTENSION" "$HTTP_ADDRESS" $ENABLE_ELASTIC
           rm -f "$LOCKFILE"
       fi
       trap - INT TERM EXIT
    else
       echo "Lockfile: $LOCKFILE exists. Only one instance of the"
       echo "enterprise manager can be running using the home directory"
       echo "$MANAGEMENT_HOME."
       echo ""
       echo "If no other copies of the enterprise manager are running,"
       echo "delete $LOCKFILE and re-run this start-up script."
    fi
}


if [ $# -gt 0 ]
then
    while getopts "hbp:o:m:l:a:" Option
    do
        case $Option in
            h ) usage;;
            b ) BACKGROUND=true;;
            p ) HTTP_PORT=$OPTARG;;
            m ) MANAGEMENT_HOME=$OPTARG;;
            l ) LICENSE=$OPTARG;;
            x ) LIB_EXTENSION=$OPTARG;;
            a ) HTTP_ADDRESS=$OPTARG;;
            o ) ENABLE_ELASTIC=$OPTARG;;
        esac
    done
fi

# set the lockfile once management_home is fully discovered
LOCKFILE="$MANAGEMENT_HOME/lockfile"

checkManagementHome
checkJar
checkUsers
checkLicenseFile
launch
