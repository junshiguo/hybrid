#!/bin/bash

MANAGEMENT_HOME=${VEMTEST_HOME:-"$HOME/.voltdb"}
LOCKFILE="$MANAGEMENT_HOME/lockfile"

ps ux | grep enterprise_manager.jar | awk '{print $2}' | xargs kill -9 2> /dev/null
rm -f "$LOCKFILE"
